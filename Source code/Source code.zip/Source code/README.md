# LockScreen
Android lockscreen for people with perfect pitch. Available from Android 8 (API 26)

Please don't use this app if you don't have perfect pitch, you may not be able to unlock your phone in emergency situations!